public class ATMStart {
    public static void main(String[] args) {
        ATM theATM = new ATM();
        theATM.run();
    }
}
